@extends('layouts.main')

@section('title', 'Contactos')

@section('content')



    <br /><br /><br /><br />
    <div class="container">
      <h1>Contactos</h1>
      <br />
      <div class="row">
        @foreach($contactos as $linha)
        <div class="card col m-1">
          <h5 class="card-title"><b>{{$linha->nome}}</b></h5>
          <p class="card-text">Contactos: {{$linha->contacto}} {{$linha->email}}</p>
        </div>
        @endforeach
      </div>
    </div><br /><br /><br /><br />
@endsection