@extends('layouts.main')

@section('title', 'Gestão de Contactos')

@section('content')

<br /><br /><br /><br />
    <div class="container">
      <h1>Gestão de Contactos</h1>
      <br />
      <table class="table table-striped table-hover">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nome</th>
              <th scope="col">E-mail</th>
              <th scope="col">Contacto</th>
              <th scope="col">Registo</th>
              <th scope="col">Alteração</th>
              <th scope="col">Opções</th>
            </tr>
          </thead>
          <tbody>
            @foreach($contactos as $linha)
            <tr>
              <th scope="row">{{$linha->id}}</th>
              <td>{{$linha->nome}}</td>
              <td>{{$linha->email}}</td>
              <td>{{$linha->contacto}}</td>
              <td>{{$linha->created_at}}</td>
              <td>{{$linha->updated_at}}</td>
              <td>
                <a href="/atualizacao_contacto/{{$linha->id}}" class="btn btn-warning">Editar</a>
                <form action="/eliminar_contacto/delete/{{$linha->id}}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
            </tr>
            @endforeach
          </tbody>
        </table>
    </div><br /><br /><br /><br />

@endsection