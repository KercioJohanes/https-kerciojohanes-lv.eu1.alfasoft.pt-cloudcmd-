@extends('layouts.main')

@section('title', 'Atualização de Contacto')

@section('content')

<br /><br /><br /><br />
    <div class="container">
      <h1>Atualização de Contacto</h1>
      <br />
      <form action="/atualizacao_contacto/update/{{$contacto->id}}" method="POST" enctype="multipart/form-data">
      @csrf
      @method('PUT')
          <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" placeholder="Primeiro e útimo nome" id="nome" name="nome" minlength="5" value="{{$contacto->nome}}" required>
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" class="form-control" placeholder="exemplo@alfasoft.com" id="email" name="email" value="{{$contacto->email}}" required>
          </div>
          <div class="mb-3">
            <label for="contacto" class="form-label">Contacto</label>
            <input type="number" class="form-control" placeholder="934321232" id="contacto" name="contacto" min="900000000" max="999999999" value="{{$contacto->contacto}}" required>
          </div>
          <button type="submit" class="btn btn-primary">Atualizar</button>
        </form>
        </div><br /><br /><br /><br />

@endsection