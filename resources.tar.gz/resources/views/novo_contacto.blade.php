@extends('layouts.main')

@section('title', 'Novo Contacto')

@section('content')

<br /><br /><br /><br />
    <div class="container">
      <h1>Novo Contacto</h1>
      <br />
      <form action="/novo_contacto" method="POST" enctype="multipart/form-data">
      @csrf
          <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" placeholder="Primeiro e útimo nome" id="nome" name="nome" minlength="5" required>
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" class="form-control" placeholder="exemplo@alfasoft.com" id="email" name="email" required>
          </div>
          <div class="mb-3">
            <label for="contacto" class="form-label">Contacto</label>
            <input type="number" class="form-control" placeholder="934321232" id="contacto" name="contacto" min="900000000" max="999999999" required>
          </div>
          <button type="submit" class="btn btn-primary">Registar</button>
        </form>
        </div><br /><br /><br /><br />

@endsection