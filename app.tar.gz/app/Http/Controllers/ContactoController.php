<?php

namespace App\Http\Controllers;

use App\Models\Contacto;

use Illuminate\Http\Request;

class ContactoController extends Controller
{
    public function contactos() {
        $contactos = Contacto::all();
        
        return view('contactos', ['contactos' => $contactos]);
    }
    
    public function create() {
        return view('novo_contacto');
    }
    
    public function select() {
        $contactos = Contacto::all();
        
        return view('gestao_contactos', ['contactos' => $contactos]);
    }
    
    public function insert(Request $request) {
        $novo_contacto = new Contacto;
        
        $novo_contacto->nome = $request->nome;
        $novo_contacto->email = $request->email;
        $novo_contacto->contacto = $request->contacto;
        
        $novo_contacto->save();
        
        return redirect('/novo_contacto');
    }
    
    public function show($id) {
        $contacto = Contacto::findOrFail($id);
        
        return view('atualizacao_contacto', ['contacto' => $contacto]);
    }
    
    public function update(Request $request) {
        Contacto::findOrFail($request->id)->update($request->all());
        
        return redirect('/gestao_contactos');
    }
    
    public function destroy($id) {
        Contacto::findOrFail($id)->delete();
        
        return redirect('/gestao_contactos');
    }
}
