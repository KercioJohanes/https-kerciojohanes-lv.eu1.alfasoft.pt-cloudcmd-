<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
use App\Http\Controllers\ContactoController;

Route::get('/contactos', [ContactoController::class, 'contactos']);

Route::get('/gestao_contactos', [ContactoController::class, 'select']);

Route::get('/atualizacao_contacto/{id}', [ContactoController::class, 'show']);

Route::get('/novo_contacto', [ContactoController::class, 'create']);

Route::post('/novo_contacto', [ContactoController::class, 'insert']);

Route::delete('/eliminar_contacto/delete/{id}', [ContactoController::class, 'destroy']);

Route::put('/atualizacao_contacto/update/{id}', [ContactoController::class, 'update']);