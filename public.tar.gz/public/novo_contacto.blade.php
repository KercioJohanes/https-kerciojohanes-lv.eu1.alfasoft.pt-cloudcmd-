@extends('layouts.main')

@section('title', 'Novo Contacto')

@section('content')

    <h1>Novo Contacto</h1>
    <form action="/novo_contacto" method="POST" enctype="multipart/form-data">
        @csrf
        method('POST')
        <label for="nome">Nome (Primeiro e Último):</label><br>
        <input type="text" id="nome" name="nome" minlength="5" required><br>
        
        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br>
        
        <label for="contacto">Contacto:</label><br>
        <input type="number" id="contacto" name="contacto" min="900000000" max="999999999" required><br>
        
        <input type="submit" value="Registar">
    </form>

@endsection