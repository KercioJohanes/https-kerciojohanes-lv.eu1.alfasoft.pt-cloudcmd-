<?php $__env->startSection('title', 'Contactos'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Contactos</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>