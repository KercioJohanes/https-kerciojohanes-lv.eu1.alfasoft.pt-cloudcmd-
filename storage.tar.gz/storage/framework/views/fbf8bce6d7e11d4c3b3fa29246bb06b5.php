

<?php $__env->startSection('title', 'Gestão de Contactos'); ?>

<?php $__env->startSection('content'); ?>

<br /><br /><br /><br />
    <div class="container">
      <h1>Gestão de Contactos</h1>
      <br />
      <table class="table table-striped table-hover">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nome</th>
              <th scope="col">E-mail</th>
              <th scope="col">Contacto</th>
              <th scope="col">Registo</th>
              <th scope="col">Alteração</th>
              <th scope="col">Opções</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($linha->id); ?></th>
              <td><?php echo e($linha->nome); ?></td>
              <td><?php echo e($linha->email); ?></td>
              <td><?php echo e($linha->contacto); ?></td>
              <td><?php echo e($linha->created_at); ?></td>
              <td><?php echo e($linha->updated_at); ?></td>
              <td>
                <a href="/atualizacao_contacto/<?php echo e($linha->id); ?>" class="btn btn-warning">Editar</a>
                <form action="/eliminar_contacto/delete/<?php echo e($linha->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
    </div><br /><br /><br /><br />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/gestao_contactos.blade.php ENDPATH**/ ?>