

<?php $__env->startSection('title', 'Atualização de Contacto'); ?>

<?php $__env->startSection('content'); ?>

<br /><br /><br /><br />
    <div class="container">
      <h1>Atualização de Contacto</h1>
      <br />
      <form action="/atualizacao_contacto/update/<?php echo e($contacto->id); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
          <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" placeholder="Primeiro e útimo nome" id="nome" name="nome" minlength="5" value="<?php echo e($contacto->nome); ?>" required>
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" class="form-control" placeholder="exemplo@alfasoft.com" id="email" name="email" value="<?php echo e($contacto->email); ?>" required>
          </div>
          <div class="mb-3">
            <label for="contacto" class="form-label">Contacto</label>
            <input type="number" class="form-control" placeholder="934321232" id="contacto" name="contacto" min="900000000" max="999999999" value="<?php echo e($contacto->contacto); ?>" required>
          </div>
          <button type="submit" class="btn btn-primary">Atualizar</button>
        </form>
        </div><br /><br /><br /><br />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/atualizacao_contacto.blade.php ENDPATH**/ ?>