<?php $__env->startSection('title', 'Contactos'); ?>

<?php $__env->startSection('content'); ?>



    <br /><br /><br /><br />
    <div class="container">
      <h1>Contactos</h1>
      <br />
      <div class="row">
        <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card col m-1">
          <h5 class="card-title"><b><?php echo e($linha->nome); ?></b></h5>
          <p class="card-text">Contactos: <?php echo e($linha->contacto); ?> <?php echo e($linha->email); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div><br /><br /><br /><br />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/contactos.blade.php ENDPATH**/ ?>